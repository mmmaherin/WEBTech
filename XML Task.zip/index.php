<?php
$finl = simplexml_load_file("sinfo.xml");

foreach($finl->student as $s)
{
	echo "<h4><b>Student Name:</b>$s->sname</h4>";
	echo "<h4><b>ID:</b>$s->sid</h4>";
	echo "<h4><b>Cgpa:</b>$s->cgpa</h4>";
	echo "<h3><u><b>Courses Taken</b></u>:</h3>";
	
	foreach($s->courses->course as $c)
	{
		echo "<h4>Name:$c->cname|Section:$c->csec|Grade:$c->cgrade</h4>";
		
	}
	echo "<hr/>";
	
}


?>