<?php
session_start();

if(isset($_SESSION['key'])){
    $key = $_SESSION['key'];
}else{
    die('Please login!');
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
</head>
<body align="center">
<center><h1> Home</h1></center>
<hr>
    <form action="logout.php">
    <input type="submit" value="Logout">
    <br>
    <?php
    $info = $_SESSION['info'];
    $name = $info[$key];
    ?>
    <h3>Hello <?php echo $name['full_name']?></h3>
    <br>
    <br>
    <br>
    <a href="uinfo.php">Users info</a><br>
    <a href="info.php">Users login info</a>
</form>

</body>
</html>
