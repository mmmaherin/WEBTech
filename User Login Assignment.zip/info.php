<?php
session_start();

if(isset($_SESSION['key'])){
    $key = $_SESSION['key'];
}else{
    die('Please login!');
}

?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login Info</title>
	<h1 align="center">Users Login Info</h1>
</head>
<body align="center">

<hr>
<form action="logout.php">
    <a href="home.php"><input type="button" value="Home"></a>
    <input type="submit" value="Logout">
</form>
<table align="center">
    <thead>
    <tr>
        <th>SL:</th>
        <th>Username</th>
        <th>Password</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $count = 1;
    foreach ($_SESSION['info'] as $reg):
        ?>
        <tr>
            <td><?php echo $count++?></td>
            <td><?php echo $reg['username']?></td>
            <td><?php echo $reg['password']?></td>
        </tr>
    <?php endforeach;?>
    </tbody>
</table>
</body>
</html>