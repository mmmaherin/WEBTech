<?php
session_start();

function search_in_array($session, $username,$password)
{
    foreach ($session as $key=>$data)
    {
     if($data['username'] == $username){
         if($data['password'] ==  $password){
          return  $key;
         }
     }
    }
}

if(isset($_POST['submit'])){
    $username  = $_POST['username'];
    $password  = $_POST['password'];
    $key = search_in_array($_SESSION['info'],$username,$password);
    $_SESSION['key'] = $key;
    header('location: home.php');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
	<h1 align="center">Login Page</h1>
</head>
<body>

<hr/>
<table align="center">
    <form action="index.php" method="post">
        <tbody>
        <tr>
            <td> <label for="">Username</label></td>
            <td><input type="text" name="username"  ></td>
        </tr>

        <tr>
            <td><label for="">Password</label></td>
            <td><input type="password" name="password"  ></td>
        </tr>

        </tr>
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Login!">
                <a href="register.php"><input type="button" value="Register"></a>
            </td>

        </tr>
        </tbody>
    </form>
</table>
</body>
</html>