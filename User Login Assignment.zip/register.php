<?php
session_start();

if(isset($_POST['submit'])){
    $data['full_name'] = $_POST['full_name'];
    $data['username']  = $_POST['username'];
    $data['password']  = $_POST['password'];
    $data['email']  = $_POST['email'];
    $data['phone'] = $_POST['phone'];
    $_SESSION['info'][] = $data;

}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
	<h1 align="center">Registration Page</h1>
</head>
<body>
    
    <hr/>
    <table align="center">
        <form action="register.php" method="post">
                <tbody>
                    <tr>
                       <td> <label for="">Username</label></td>
                        <td><input type="text" name="username"  required></td>
                    </tr>

                    <tr>
                        <td><label for="">Password</label></td>
                        <td><input type="password" name="password"  required></td>
                    </tr>

                    <tr>
                        <td><label for="">Re-Enter Password</label></td>
                        <td><input type="password"  required></td>
                    </tr>

                    <tr>
                        <td><label for="">E-mail</label></td>
                        <td><input type="email" name="email"  required></td>
                    </tr>

                    <tr>
                        <td><label for="">Phone</label></td>
                        <td><input type="text" name="phone"  required></td>
                    </tr>

                    <tr>
                        <td><label for="">Full name</label></td>
                        <td><input type="text" name="full_name" required></td>
                    </tr>

                    <tr>
                        <td>
							<a href="index.php"><input type="button" value="     Login    "></a>
						</td>
                        <td>
                            <input type="submit" name="submit" value="  Register!  ">
                            <input type="reset" value="  clean  ">
                        </td>
                    </tr>
					
                </tbody>
            </form>
    </table>
</body>
</html>