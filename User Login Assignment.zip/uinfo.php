<?php
session_start();

if(isset($_SESSION['key'])){
    $key = $_SESSION['key'];
}else{
    die('Please login!');
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>uinfo</title>
	<center><h1>User Info</h1></center>
</head>

<body align="center">

<hr>
<form action="logout.php">
	<a href="home.php"><input type="button" value="Home"></a>
    <input type="submit" value="Logout">
    <br>
    <table align="center">
        <thead>
            <tr>
                <th>SL:</th>
                <th>Phone</th>
                <th>Full name</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $count = 1;
        foreach ($_SESSION['info'] as $reg):

            ?>

            <tr>
                <td><?php echo $count++?></td>
                <td><?php echo $reg['phone']?></td>
                <td><?php echo $reg['full_name']?></td>
                <td><?php echo $reg['email']?></td>
            </tr>
        <?php endforeach;?>
        </tbody>
    </table>
    <br>
    <br>
    <br>

</form>

</body>
</html>
